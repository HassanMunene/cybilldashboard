module.exports = {
  content: ['./views/**/*.{html,ejs}', './public/js/*.js'],
  theme: {
    extend: {
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
